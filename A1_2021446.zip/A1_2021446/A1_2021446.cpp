# include <iostream>
# include <string>

using namespace std;
struct Book
{
	int ID;
	string Book_name;
	string Author;
	string ISBN;
	int price;
	int pages;

	void Print_All()
	{
		cout << " Book ID : " << ID << endl;
		cout << "Book name : " << Book_name << endl;
		cout << "Book Author : " << Author << endl;
		cout << "Book ISBN : " << ISBN << endl;
		cout << "Book Price : " << price << endl;
		cout << "Book Pages : " << pages << endl;
	}
};
struct Student
{
	int ID;
	string std_name;
	int rollno;
	void Print_All()
	{
		cout << "Student ID : " << ID << endl;
		cout << "Student name : " << std_name << endl;
		cout << "Student roll number : " << rollno << endl;
	}
};
struct Book_list
{
	Book books[5];
	int count1=0;
	void Print_All()
	{
		if (count1 == 0)
			cout << "There are no books registered." << endl;
		else
		{
			for (int i = 0; i < count1; i++)
			{
				books[i].Print_All();
				cout << endl;
			}
		}
	}
	void Add_Book()
	{
		if (count1 == 5)
			cout << "Registration slots are full." << endl;
		else
		{
			cout << "Enter Book ID : ";
			cin >> books[count1].ID;
			if (count1 > 0)
			{
				for (int i = 0; i < count1; i++)
				{
					if (books[i].ID == books[count1].ID)
					{
						while (books[i].ID == books[count1].ID)
						{
							cout << "ID already taken. Enter another ID : ";
							cin>> books[count1].ID;
						}
					}
				}
			}
			cin.ignore();
			cout << "Enter book name : ";
			getline(cin, books[count1].Book_name);
			cout << "Enter book author : ";
			getline(cin, books[count1].Author);
			cout << "Enter book ISBN : ";
			getline(cin, books[count1].ISBN);
			if (count1 > 0)
			{
				for (int i = 0; i < count1; i++)
				{
					if (books[i].ISBN == books[count1].ISBN)
					{
						while (books[i].ISBN == books[count1].ISBN)
						{
							cout << "Invalid ISBN. Enter another ISBN : ";
							getline(cin, books[count1].ISBN);
						}
					}
				}
			}
			cout << "Enter book pages : ";
			cin >> books[count1].pages;
			cout << "Enter book price : ";
			cin >> books[count1].price;
			count1++;
			cout << "Book added successfully." << endl;
		}
	}
	void Delete_book()
	{
		if (count1 == 0)
			cout << "There are no books registered." << endl;
		else
		{
			int delete_ID;
			cout << "Enter the book ID : ";
			cin >> delete_ID;
			for (int i = 0; i < count1; i++)
			{
				if (books[i].ID == delete_ID)
				{
					for (int j = i; j < count1 - 1; j++)
					{
						Book temp = books[j];
						books[j] = books[j + 1];
						books[j + 1] = temp;
					}
					count1--;
					cout << "Book deleted successfully"<<endl;
					break;
				}
				else if (i == count1 - 1 && books[i].ID != delete_ID)
					cout << "Book doesnot exist." << endl;
			}
		}
	}
	void Delete_all()
	{
		if (count1 == 0)
			cout << "There are no books registered." << endl;
		else
		{
			for (int i = 0; i < count1; i++)
			{
				books[i].ID = 0;
				books[i].Book_name = " ";
				books[i].Author = " ";
				books[i].ISBN = " ";
				books[i].pages = 0;
				books[i].price = 0;
			}
			count1 = 0;
			cout << "All books deleted successfully." << endl;
		}
	}
	void Show_Book()
	{
		if (count1 == 0)
			cout << "There are no books registered." << endl;
		else
		{
			int check_ID;
			cout << "Enter the ID you want to check : ";
			cin >> check_ID;
			for (int i = 0; i < count1; i++)
			{
				if (books[i].ID == check_ID)
				{
					cout << "Book name : " << books[i].Book_name << endl;
					cout << "Book Author : " << books[i].Author << endl;
					cout << "Book ISBN : " << books[i].ISBN << endl;
					cout << "Book price : " << books[i].price << endl;
					cout << "Book pages : " << books[i].pages << endl;
					break;
				}
				else if (i == count1 - 1 && books[i].ID != check_ID)
					cout << "The book doesnot exist." << endl;
			}
		}
	}
	void Sort(int n)
	{
		if (count1 == 0)
			cout << "There are no books registered." << endl;
		else
		{
			if (n == 0)
			{
				for (int i = 0; i < count1; i++)
				{
					for (int j = 0; j < count1 - i - 1; j++)
					{
						if (books[j].ID > books[j + 1].ID)
						{
							Book temp = books[j];
							books[j] = books[j + 1];
							books[j + 1] = temp;
						}
					}
				}
				cout << "Books sorted successfully." << endl;
			}
			else if (n == 1)
			{
				for (int i = 0; i < count1; i++)
				{
					for (int j = 0; j < count1 - i - 1; j++)
					{
						if (books[j].ID < books[j + 1].ID)
						{
							Book temp = books[j];
							books[j] = books[j + 1];
							books[j + 1] = temp;
						}
					}
				}
				cout << "Books sorted successfully." << endl;
			}
		}
	}
};
struct Student_list
{
	Student std[5];
	int count2=0;
	void Print_all()
	{
		if (count2 == 0)
			cout << "There are no students registered." << endl;
		else
		{
			for (int i = 0; i < count2; i++)
			{
				std[i].Print_All();
			}
		}
	}
	void Add_Student()
	{
		if (count2 == 5)
			cout << "Registration slots are full." << endl;
		else
		{
			cout << "Enter student ID : ";
			cin >> std[count2].ID;
			if (count2 > 0)
			{
				for (int i = 0; i < count2; i++)
				{
					if (std[i].ID == std[count2].ID)
					{
						while (std[i].ID == std[count2].ID)
						{
							cout << "ID already taken. Enter another ID : ";
							cin >> std[count2].ID;
						}
					}
				}
			}
			cin.ignore();
			cout << "Enter student name : ";
			getline(cin, std[count2].std_name);
			cout << "Enter student roll number : ";
			cin >> std[count2].rollno;
			if (count2 > 0)
			{
				for (int i = 0; i < count2; i++)
				{
					if (std[i].rollno == std[count2].rollno)
					{
						while (std[i].rollno == std[count2].rollno)
						{
							cout << "Invalid roll number.Enter again : ";
							cin >> std[count2].rollno;
						}
					}
				}
			}
			count2++;
			cout << "Student added successfully." << endl;
		}
	}
	void Delete_student()
	{
		if (count2 == 0)
			cout << "There are no students registered." << endl;
		else
		{
			int delete_ID;
			cout << "Enter student ID to remove : ";
			cin >> delete_ID;
			for (int i = 0; i < count2; i++)
			{
				if (std[i].ID == delete_ID)
				{
					for (int j = i; j < count2 - 1; j++)
					{
						Student temp = std[j];
						std[j] = std[j + 1];
						std[j + 1] = temp;
					}
					count2--;
					cout << "Student deleted successfully." << endl;
					break;
				}
				else if (i == count2 - 1 && std[i].ID != delete_ID)
					cout << "The student doesnot exist." << endl;
			}
		}
	}
};
int main()
{
	int x;
	Book_list a;
	Student_list b;

	cout << "Main menu : " << endl << endl;
	cout << "1. Add New student." << endl;
	cout << "2. Delete existing student." << endl;
	cout << "3. Show all students." << endl;
	cout << "4. Add new book." << endl;
	cout << "5. Delete existing book." << endl;
	cout << "6. Delete all books." << endl;
	cout << "7. Show particular book." << endl;
	cout << "8. Show all books." << endl;
	cout << "9. Sort books in ascending order." << endl;
	cout << "10. Sort books in descending order." << endl;
	cout << "11. Exit." << endl << endl;
	bool exit = false;

	while (1)
	{
		cout << "Enter your desired option : ";
		cin >> x;
		switch (x)
		{
		case 1:
			b.Add_Student();
			break;
		case 2:
			b.Delete_student();
			break;
		case 3:
			b.Print_all();
			break;
		case 4:
			a.Add_Book();
			break;
		case 5:
			a.Delete_book();
			break;
		case 6:
			a.Delete_all();
			break;
		case 7:
			a.Show_Book();
			break;
		case 8:
			a.Print_All();
			break;
		case 9:
			a.Sort(0);
			break;
		case 10:
			a.Sort(1);
			break;
		case 11:
			exit = true;
			break;
		default:
			cout << "Invalid input.Enter again."<<endl;
		}
		if (exit)
			break;
		char a;
		cout << "Do you want to enter again. Y for yes, N for no : ";
		cin >> a;
		if (a != 'Y' && a != 'y' && a != 'N' && a != 'n')
		{
			while (a != 'Y' && a != 'y' && a != 'N' && a != 'n')
			{
				cout << "Invalid input.Enter again : ";
				cin >> a;
			}
		}
		if (a == 'Y' || a == 'y')
			continue;
		else
			break;
	}
}