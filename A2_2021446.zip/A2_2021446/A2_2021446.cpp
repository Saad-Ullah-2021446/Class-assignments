# include <iostream>
# include <string>

using namespace std;

size_t Mystrlen(const char*);
char* Mystrtok(char*, const char*);
int Mystrncmp(const char*, const char*,size_t);
int Mystrcmp(const char*, const char*);
char* Mystrncat(char*, const char*, size_t);
char* Mystrcat(char*, const char*);
char* Mystrncpy(char*, const char*, size_t);
char* Mystrcpy(char*, const char*);

int main()
{
	//Every function is working perfectly. You can check each function by uncommenting them.
	//Mystrcpy
	/*string s2;
	char* s2ptr, * s1ptr;
	cout << "Enter the string : ";
	getline(cin, s2);
	s2ptr = &s2[0];
	char s1[30];
	s1ptr = s1;
	cout << "The string copy is : " << Mystrcpy(s1ptr, s2ptr) << endl;*/
	//Mystrncpy
	/*
	string str;
	size_t n;
	char* strptr1, * strptr2,str2[30];
	cout << "Enter the string : ";
	getline(cin, str);
	cout << "Enter the number : ";
	cin >> n;
	strptr1 = &str[0];
	strptr2 = str2;
	cout << "The copy string is : " << Mystrncpy(strptr2, strptr1, n) << endl; 
	*/
	//Mystrcat
	/*
	string str, str2;
	char* strptr1, * strptr2;
	cout << "Enter the first string : ";
	getline(cin, str);
	cout << "Enter the second string : ";
	getline(cin, str2);
	strptr1 = &str[0];
	strptr2 = &str2[0];
	cout << "The appended string is : " << Mystrcat(strptr1, strptr2); 
	*/
	//Mystrncat
	/*
		size_t n;
	string s1, s2;
	char* s1ptr, * s2ptr;
	cout << "Enter the string : ";
	getline(cin, s1);
	cout << "Enter another string : ";
	getline(cin, s2);
	cout << "Enter the number : ";
	cin >> n;
	s1ptr = &s1[0];
	s2ptr = &s2[0];
	cout << "The appended string is : " << Mystrncat(s1ptr, s2ptr, n);
	*/
	//Mystrcmp
	/*
		string s1, s2;
	char* s1ptr,* s2ptr;
	cout << "Enter the string : ";
	getline(cin, s1);
	cout << "Enter another string : ";
	getline(cin, s2);
	s1ptr = &s1[0];
	s2ptr = &s2[0];
	if (Mystrcmp(s1ptr, s2ptr) > 0)
		cout << "They are not the same.s1 is larger.";
	else if (Mystrcmp(s1ptr, s2ptr) == 0)
		cout << "s1 and s2 are same.";
	else
		cout << "They are not the same.s2 is larger.";
	*/
	//Mystrncmp
	/*
	int n;
	string s1, s2;
	char* s1ptr, * s2ptr;
	cout << "Enter the string : ";
	getline(cin, s1);
	cout << "Enter another string : ";
	getline(cin, s2);
	s1ptr = &s1[0];
	s2ptr = &s2[0];
	cout << "Enter the number : ";
	cin >> n;
	if (Mystrncmp(s1ptr, s2ptr, n) > 0)
		cout << "They are not the same.s1 is larger.";
	else if (Mystrncmp(s1ptr, s2ptr, n) == 0)
		cout << "They are the same upto the value of number entered.";
	else
		cout << "They are not the same.s2 is larger.";
	*/
	//Mystrtok
	/*
	    string s1;
    char* s1ptr, * s2ptr, s2;
    cout << "Enter the string : ";
    getline(cin, s1);
    cout << "Enter the token : ";
    cin >> s2;
    s1ptr = &s1[0];
    s2ptr = &s2;
    cout << "The tokenized string is : ";
    cout << Mystrtok(s1ptr, s2ptr);
    cout << Mystrtok(s1ptr, s2ptr);
    cout << Mystrtok(s1ptr, s2ptr);
	*/
    //MystrLen
    /*
	string str;
	const char* strptr;
	cout << "Enter the string : ";
	getline(cin, str);
	strptr = &str[0];
	cout << "The length is : " << MystrLen(strptr);
	*/
    return 0;
}
char* Mystrcpy(char* s1, const char* s2)
{
	int i;
	for (i = 0; *(s2 + i) != '\0'; i++)
	{
		*(s1 + i) = *(s2 + i);
	}
	s1[i] = '\0';
	return s1;
}
char* Mystrncpy(char* s1, const char* s2, size_t n)
{
	int i;
	for (i = 0; i < n; i++)
	{
		*(s1 + i) = *(s2 + i);
	}
	s1[i] = '\0';
	return s1;
}
char* Mystrcat(char* s1, const char* s2)
{
	int i = 0;
	while (s1[i] != '\0')
		i++;
	int j;
	for (j = 0; s2[j] != '\0'; j++)
		s1[i + j] = s2[j];
	s1[i + j] = '\0';
	return s1;
}
char* Mystrncat(char* s1, const char* s2, size_t n)
{
	int i = 0, j;
	while (s1[i] != '\0')
		i++;
	for (j = 0; j < n; j++)
		s1[i + j] = s2[j];
	s1[i + j] = '\0';
	return s1;
}
int Mystrcmp(const char* s1, const char* s2)
{
	int i;
	for (i = 0; s1[i] != '\0'; i++)
	{
		if (s1[i] == s2[i])
			continue;
		else
			break;
	}
	if (s1[i] == '\0' && s2[i] == '\0')
		return 0;
	else if (s1[i] != '\0')
		return 1;
	else if (s1[i] == '\0' && s2[i] != '\0')
		return -1;
}
int Mystrncmp(const char* s1, const char* s2, size_t n)
{
	int i;
	for (i = 0; i < n; i++)
	{
		if (s1[i] == s2[i])
		{
			if (i == n - 1)
				return 0;
		}
		else
			break;
	}
	while (s1[i] != '\0' && s2[i] != '\0')
		i++;
	if (s1[i] != '\0')
		return 1;
	else
		return -1;
}
char* Mystrtok(char* s1, const char* s2)
{
	static int count = 0;
	int x = 0;
	while (s1[count + x] != '\0' && s1[count + x] != *s2)
		x++;
	char* arr = new char[x];
	for (int i = 0; i < x; i++)
		arr[i] = s1[count + i];
	count += (++x);
	s1 = arr;
	return s1;
}
size_t MystrLen(const char* str)
{
	int count = 0;
	while (*str != '\0')
	{
		count++;
		str++;
	}
	return count;
}