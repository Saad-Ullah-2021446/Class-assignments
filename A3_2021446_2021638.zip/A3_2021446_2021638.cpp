# include <iostream>
# define _USE_MATH_DEFINES
# include <math.h>

using namespace std;
class donut
{
private:
	const float tspacing = 0.07;
	const float phispacing = 0.02;
	const float r1 = 1;
	const float r2 = 2;
	const float k2 = 5;
	float A, B;
public:
	donut()
	{
		A = 0, B = 0;
	}
	void draw()
	{
		const int screen_width = 60;
		const int screen_height = 40;
		while (1)
		{
			A += 0.1, B += 0.1;
			const float k1 = 20;
			float cosA = cos(A), sinA = sin(A);
			float cosB = cos(B), sinB = sin(B);

			char output[screen_width][screen_height];
			float zbuffer[screen_width][screen_height];

			for (int i = 0; i < screen_width; i++)
			{
				for (int j = 0; j < screen_height; j++)
				{
					output[i][j] = ' ';
					zbuffer[i][j] = 0;
				}
			}

			for (float theta = 0; theta < 2 * M_PI; theta += tspacing)
			{
				float cost = cos(theta), sint = sin(theta);

				for (float phi = 0; phi < 2 * M_PI; phi += phispacing)
				{
					float cosphi = cos(phi), sinphi = sin(phi);

					float Cx = r2 + r1 * cost;
					float Cy = r1 * sint;

					float x = Cx * (cosB * cosphi + sinA * sinB * sinphi) - Cy * cosA * sinB;
					float y = Cx * (cosphi * sinB - cosB * sinA * sinphi) + Cy * cosA * cosB;
					float z = k2 + Cx * cosA * sinphi + Cy * sinA;
					float inv_z = 1 / z;

					int xp = (screen_width / 2) + k1 * inv_z * x;
					int yp = (screen_height / 2) - k1 * inv_z * y;

					float L = cosphi * cost * sinB - cosA * cost * sinphi - sinA * sint + cosB * (cosA * sint - cost * sinA * sinphi);

					if (L > 0)
					{
						if (inv_z > zbuffer[xp][yp])
						{
							zbuffer[xp][yp] = inv_z;
							int L_index = L * 8;
							switch (L_index)
							{
							case 0:
								output[xp][yp] = '.';
								break;
							case 1:
								output[xp][yp] = ',';
								break;
							case 2:
								output[xp][yp] = '-';
								break;
							case 3:
								output[xp][yp] = '~';
								break;
							case 4:
								output[xp][yp] = ':';
								break;
							case 5:
								output[xp][yp] = ';';
								break;
							case 6:
								output[xp][yp] = '=';
								break;
							case 7:
								output[xp][yp] = '!';
								break;
							case 8:
								output[xp][yp] = '*';
								break;
							case 9:
								output[xp][yp] = '#';
								break;
							case 10:
								output[xp][yp] = '$';
								break;
							case 11:
								output[xp][yp] = '@';
								break;
							}
						}
					}
				}
			}
			for (int j = 0; j < screen_height; j++)
			{
				for (int i = 0; i < screen_width; i++)
				{
					cout << output[i][j];
				}
				cout << "\n";
			}
			system("cls");
		}
	}
};

int main()
{
	donut d;
	d.draw();
	
	return 0;
}