# include <iostream>

using namespace std;

class Mystring
{
private:
	int size;
	char* arr;
public:
	Mystring()
	{
		size = 50;
		arr = new char[size];

		for (int i = 0; i < size; i++)
		{
			arr[i] = ' ';
		}
	}
	Mystring(char a[])
	{
		size = 50;
		arr = new char[size];
		int i;
		for (i = 0; a[i] != '\0'; i++)
		{
			arr[i] = a[i];
		}
		arr[i] = '\0';
		size = i;
	}
	Mystring(int b)
	{
		size = b;
		arr = new char[size];
	}
	int get_size()
	{
		return size;
	}
	Mystring operator +(Mystring b)
	{
		Mystring c(2 * size);
		int i, j;
		for (i = 0; arr[i] != '\0'; i++)
		{
			c.arr[i] = arr[i];
		}
		for (j = 0; b.arr[j] != '\0'; j++)
		{
			c.arr[i + j] = b.arr[j];
		}
		c.arr[i + j] = '\0';
		return c;
	}
	void operator +=(Mystring b)
	{
		int i = 0, j;
		size += b.get_size();
		while (arr[i] != '\0')
		{
			i++;
		}
		for (j = 0; b.arr[j] != '\0'; j++)
		{
			arr[i + j] = b.arr[j];
		}
		arr[i + j] = '\0';

	}
	char& operator [](int a)
	{
		if (a >= 0 && a < size)
			return arr[a];
		else
			cout << "Invalid index." << endl;
	}
	
	
	bool operator ==(Mystring b)
	{
		int i = 0;
		while (1)
		{
			if (arr[i] == '\0' && arr[i] == b.arr[i])
				return true;
			else if (arr[i] != b.arr[i])
				return false;
			i++;
		}
	}
	bool operator !=(Mystring b)
	{
		int i = 0;
		while (1)
		{
			if (arr[i] == '\0' && arr[i] == b.arr[i])
				return false;
			else if (arr[i] != b.arr[i])
				return true;
			i++;
		}
	}
	bool operator >(Mystring b)
	{
		if (size > b.size)
			return true;
		else
			return false;

	}
	bool operator <(Mystring b)
	{
		if (size < b.size)
			return true;
		else
			return false;
	}
	Mystring operator ()(int a, int b)
	{
		Mystring c;
		int j = 0;
		for (int i = a; i <= b; i++)
		{
			c.arr[j] = arr[i];
			j++;
		}
		c.arr[j] = '\0';
		return c;
	}
	friend ostream& operator <<(ostream& out, Mystring b)
	{
		out << b.arr;
		return out;
	}
	friend istream& operator >>(istream& in, Mystring b)
	{
		in >> b.arr;
		return in;
	}
	void operator =(Mystring b)
	{
		size = b.size;
		int i;
		for (i = 0; b.arr[i] != '\0'; i++)
		{
			arr[i] = b.arr[i];
		}
		arr[i] = '\0';
	}
	Mystring operator <<(int a)
	{
		Mystring b;
		for (int i = 0; i < a; i++)
		{
			b.arr[i] = arr[i];
		}
		b.arr[a] = '\0';
		int i;
		for (i = 0; i < size - a; i++)
		{
			arr[i] = arr[i + a];
		}
		arr[i] = '\0';
		return b;
	}
	Mystring operator >>(int a)
	{
		Mystring b;
		int j = 0;
		for (int i = size - 1; i > size-1-a; i--)
		{
			b.arr[j] = arr[i];
			j++;
		}
		b.arr[j] = '\0';
		
		Mystring temp;
		for (int i = 0; i < size; i++)
		{
			temp.arr[i] = arr[i];
		}
		delete[]arr;
		size--;
		arr = new char[size];
		for (int i = 0; i < size; i++)
		{
			arr[i] = temp.arr[i];
		}
		arr[size-1] = '\0';
		return b;
	}
};


int main()
{
	char arr[] = "abcdef", arr2[] = "1234567",d;
	Mystring a(arr), b(arr2), c;

}